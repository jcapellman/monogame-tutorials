﻿namespace chapter_04.Enum
{
    public enum Events
    {
        GAME_QUIT
    }
}