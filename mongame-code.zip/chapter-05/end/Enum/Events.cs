﻿namespace chapter_05.Enum
{
    public enum Events
    {
        GAME_QUIT
    }
}