﻿namespace chapter_06.Enum
{
    public enum Events
    {
        GAME_QUIT
    }
}