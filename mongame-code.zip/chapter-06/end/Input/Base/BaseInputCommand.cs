﻿namespace chapter_06.Input.Base
{
    public class BaseInputCommand { }
}
