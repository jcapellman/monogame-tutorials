﻿using chapter_06.Input.Base;

namespace chapter_06.Input
{
    public class SplashInputCommand : BaseInputCommand 
    {
        // Out of Game Commands
        public class GameSelect : SplashInputCommand { }
    }
}
