﻿namespace chapter_07.Engine.Input
{
    public class BaseInputCommand { }
}
