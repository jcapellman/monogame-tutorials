﻿namespace chapter_07.Engine.States
{
    public class BaseGameStateEvent 
    {
        public class GameQuit : BaseGameStateEvent { }
    }
}
