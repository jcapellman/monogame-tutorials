﻿using chapter_07.Engine.States;

namespace chapter_07.States.Gameplay
{
    public class GameplayEvents : BaseGameStateEvent
    {
        public class PlayerShoots : GameplayEvents { }
    }
}
