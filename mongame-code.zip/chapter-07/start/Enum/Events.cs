﻿namespace chapter_07.Enum
{
    public enum Events
    {
        GAME_QUIT
    }
}