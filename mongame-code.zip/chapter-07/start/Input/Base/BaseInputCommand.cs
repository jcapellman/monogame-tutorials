﻿namespace chapter_07.Input.Base
{
    public class BaseInputCommand { }
}
