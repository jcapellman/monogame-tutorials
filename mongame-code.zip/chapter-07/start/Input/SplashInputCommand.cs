﻿using chapter_07.Input.Base;

namespace chapter_07.Input
{
    public class SplashInputCommand : BaseInputCommand 
    {
        // Out of Game Commands
        public class GameSelect : SplashInputCommand { }
    }
}
