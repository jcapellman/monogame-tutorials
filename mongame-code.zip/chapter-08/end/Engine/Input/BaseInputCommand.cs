﻿namespace chapter_08.Engine.Input
{
    public class BaseInputCommand { }
}
