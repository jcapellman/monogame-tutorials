﻿namespace chapter_08.Engine.States
{
    public class BaseGameStateEvent 
    {
        public class GameQuit : BaseGameStateEvent { }
    }
}
