﻿using chapter_08.Engine.Input;

namespace chapter_08.Input
{
    public class SplashInputCommand : BaseInputCommand 
    {
        // Out of Game Commands
        public class GameSelect : SplashInputCommand { }
    }
}
