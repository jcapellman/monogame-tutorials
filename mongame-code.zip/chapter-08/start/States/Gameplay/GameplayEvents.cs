﻿using chapter_08.Engine.States;

namespace chapter_08.States.Gameplay
{
    public class GameplayEvents : BaseGameStateEvent
    {
        public class PlayerShoots : GameplayEvents { }
    }
}
