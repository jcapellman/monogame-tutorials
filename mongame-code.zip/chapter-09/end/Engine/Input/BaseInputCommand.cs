﻿namespace chapter_09.Engine.Input
{
    public class BaseInputCommand { }
}
