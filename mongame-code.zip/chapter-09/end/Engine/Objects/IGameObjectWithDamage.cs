﻿namespace chapter_09.Engine.Objects
{
    public interface IGameObjectWithDamage
    {
        int Damage { get; }
    }
}
