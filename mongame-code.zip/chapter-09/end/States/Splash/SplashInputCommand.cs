﻿using chapter_09.Engine.Input;

namespace chapter_09.Input
{
    public class SplashInputCommand : BaseInputCommand 
    {
        // Out of Game Commands
        public class GameSelect : SplashInputCommand { }
    }
}
