﻿namespace chapter_10.Engine.Input
{
    public class BaseInputCommand { }
}
