﻿namespace chapter_10.Engine.Objects
{
    public interface IGameObjectWithDamage
    {
        int Damage { get; }
    }
}
