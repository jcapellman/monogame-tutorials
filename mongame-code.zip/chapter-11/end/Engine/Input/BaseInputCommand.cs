﻿namespace chapter_11.Engine.Input
{
    public class BaseInputCommand { }
}
