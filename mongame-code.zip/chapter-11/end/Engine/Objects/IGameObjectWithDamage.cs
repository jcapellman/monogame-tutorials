﻿namespace chapter_11.Engine.Objects
{
    public interface IGameObjectWithDamage
    {
        int Damage { get; }
    }
}
