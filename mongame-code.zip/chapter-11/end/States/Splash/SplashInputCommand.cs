﻿using chapter_11.Engine.Input;

namespace chapter_11.Input
{
    public class SplashInputCommand : BaseInputCommand 
    {
        // Out of Game Commands
        public class GameSelect : SplashInputCommand { }
    }
}
